package com.example.retrofit_send_location;

public class LocationData {

    LocationClass location;

    public LocationClass getLocation() {
        return location;
    }

    public void setLocation(LocationClass location) {
        this.location = location;
    }

    public static class LocationClass{
        double latitude, longitude;
        int timestamp;
        String timestamp_ymd;

        public int getTimestampAPI() {
            return timestamp;
        }

        public void setTimestampAPI(int timestampAPI) {
            this.timestamp = timestampAPI;
        }

        public String getTimestamp_ymd() {
            return timestamp_ymd;
        }

        public void setTimestamp_ymd(String timestamp_ymd) {
            this.timestamp_ymd = timestamp_ymd;
        }



        public double getLatitude() {
            return latitude;
        }

        public void setLatitude(double latitude) {
            this.latitude = latitude;
        }

        public double getLongitude() {
            return longitude;
        }

        public void setLongitude(double longitude) {
            this.longitude = longitude;
        }
    }
}
