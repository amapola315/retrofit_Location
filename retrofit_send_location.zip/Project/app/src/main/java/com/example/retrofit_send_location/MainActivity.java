package com.example.retrofit_send_location;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Headers;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import java.lang.reflect.Type;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;

//import com.androidnetworking.AndroidNetworking;



public class MainActivity extends AppCompatActivity {

    interface RequestLocation{
        @Headers("Content-Type: application/json")
        @GET("/")
        Call<LocationData>  getLocation();
    }

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=findViewById(R.id.textView);

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .retryOnConnectionFailure(true)
                .connectTimeout(15, TimeUnit.SECONDS)
                .build();

       // AndroidNetworking.initialize(getApplicationContext());

        Gson gson = new GsonBuilder()
                //.registerTypeAdapter(LocationData.class, new LocationDataDeserializer())
                .setLenient()
                .create();


        //AndroidNetworking.setParserFactory(new GsonParserFactory(gson));

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.21.236.17:80/")
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        RequestLocation requestLocation = retrofit.create(RequestLocation.class);

        //  JSON body
       // String jsonBody = "{\"key\":\"value\"}";

        // Crear un objeto de solicitud
        //RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"), jsonBody);


        requestLocation.getLocation().enqueue(new Callback<LocationData>() {

            public void onResponse(Call<LocationData> call, Response<LocationData> response) {
                if (response.isSuccessful()) {

                    System.out.println("-----> onResponse: ");

                    // Mostrar la respuesta en la consola o en un Log
                    System.out.println(response.body().toString());

                    LocationData locationData = response.body();
                    if (locationData != null) {
                        System.out.println("-----> LocationData != null ");

                        double latitude = locationData.getLocation().getLatitude();
                        textView.setText(String.valueOf(latitude));
                        //textView.setText(String.valueOf(latitude));
                    }
                } else {
                    textView.setText("Error from server answer");
                }

            }

            @Override
            public void onFailure(Call<LocationData> call, Throwable t) {
                System.out.println("onFailure: "+t.getMessage());

                textView.setText(t.getMessage());

            }
        });

    }
}