package com.example.retrofit_send_location;

import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonDeserializationContext;
import java.lang.reflect.Type;

public class LocationDataDeserializer implements JsonDeserializer<LocationData> {

    @Override
    public LocationData deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        JsonObject jsonObject = json.getAsJsonObject();

        double latitude = jsonObject.get("latitude").getAsDouble();
        System.out.println("latitude: "+latitude);
        double longitude = jsonObject.get("longitude").getAsDouble();
        int timestamp = jsonObject.get("timestamp").getAsInt();
        String timestamp_ymd = jsonObject.get("timestamp_ymd").getAsString();

        LocationData.LocationClass location = new LocationData.LocationClass();
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setTimestampAPI(timestamp);
        location.setTimestamp_ymd(timestamp_ymd);

        LocationData locationData = new LocationData();
        locationData.setLocation(location);

        return locationData;
    }
}
